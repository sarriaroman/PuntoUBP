<?php

// Generado por translationbrowser 

$spanish = array( 
	 'friendrequest'  =>  "Solicitud de amistad" , 
	 'friendrequests'  =>  "Solicitud de amistades" , 
	 'friendrequests:title'  =>  "%s's Solicitudes de amistad" , 
	 'newfriendrequests'  =>  "Nueva solicitud de amistad" , 
	 'friendrequest:add:exists'  =>  "Ya has enviado la solicitud de amistad a %s." , 
	 'friendrequest:add:failure'  =>  "Perdon pero ha ocurrido un error en el sistema que impide que se pueda concretar la solicitud. Por favor intenta mas tarde." , 
	 'friendrequest:add:successful'  =>  "Tenes una solicitud para ser amigo de %s. Las persona deberá aprobar tu solicitud para que aparezcas en su lista de amigos." , 
	 'friendrequest:newfriend:subject'  =>  "%s quiere ser tu amigo!" , 
	 'friendrequest:successful'  =>  "Ahora sos amigo de %s!" , 
	 'friendrequest:remove:success'  =>  "Has eliminado exitosamente la solicitud." , 
	 'friendrequest:remove:fail'  =>  "Imposible eliminar la solicitud." , 
	 'friendrequest:approvefail'  =>  "Se produjo un error desconocido al tratar de agregar a %s como amigo!"
); 

add_translation('es', $spanish); 

?>